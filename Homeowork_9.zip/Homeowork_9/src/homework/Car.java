package homework;

/* 			Vijay Reddy Thippana
 * 			Homework 9
 */

public abstract class Car {

	
			int horsePower;
			String name;
			
			abstract void ShowHP();
}
