package homework;


/* 			Vijay Reddy Thippana
 * 			Homework 9
 */

public class Sedan extends Car {

	
	Sedan() {
		this.name = "Sedan";
		this.horsePower = 250;
	}
	
	Sedan(int horsePower){
		this.name = "Sedan";
		this.horsePower = horsePower;
	}
	@Override
	void ShowHP() {
		
		System.out.println(this.name+" car has "+this.horsePower+" horsepower");

	}

}
