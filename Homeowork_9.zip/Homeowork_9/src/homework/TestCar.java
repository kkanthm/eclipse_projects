package homework;

/* 			Vijay Reddy Thippana
 * 			Homework 9
 */

public class TestCar {

	public static void main(String[] args) {
		
		Sedan sedanCar1 = new Sedan();
		Truck truck1 = new Truck(400);
		
		sedanCar1.ShowHP();
		truck1.ShowHP();

	}

}
