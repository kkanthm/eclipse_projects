package homework;


/* 			Vijay Reddy Thippana
 * 			Homework 9
 */


public class Truck extends Car {

	
	Truck() {
		this.name = "Truck";
		this.horsePower = 325;
	}
	
	Truck(int horsePower){
		this.name = "Truck";
		this.horsePower = horsePower;
	}
	@Override
	void ShowHP() {
		
		System.out.println(this.name+" car has "+this.horsePower+" horsepower");

	}

}
