package sample;

import java.util.*;

public class Controller {
	

	
	public static String getQuestion() {
		return "";
	}
	
	public static String getResult() {
		return "";
	}
	
	public static List<String> getOtherOptions(){
		return new ArrayList<String>();
	}
}

