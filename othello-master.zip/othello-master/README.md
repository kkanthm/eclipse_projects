Archive of a project from my CS class at HS. A basic Othello game with a basic AI that ended up being effectively Minimax.
